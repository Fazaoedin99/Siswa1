package com.example.misbahudinfaza_siswa

data class SiswaData (var nis:String,
                 var nama:String,
                 var jekel:String,
)